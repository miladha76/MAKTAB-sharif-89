from fastapi import FastAPI

app = FastAPI()


items = [

{"name": "apple", "description": "A delicious fruit"},

{"name": "banana", "description": "A long, curved fruit"},

{"name": "orange", "description": "A round, citrus fruit"},

{"name": "pineapple", "description": "A spiky fruit with a sweet, juicy interior"},

]


@app.get("/search")

async def search_item(query: str):

    results = []

    for item in items:

        if query.lower() in item['name'].lower() or query.lower() in item['description'].lower():

            results.append(item)

    return {"results": results}