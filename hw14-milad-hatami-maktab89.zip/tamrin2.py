from fastapi import FastAPI, Request, HTTPException 

import requests


app = FastAPI()


@app.exception_handler(HTTPException)

async def handle_http_exception(request: Request, exc: HTTPException):

    if exc.status_code == 500:

# Send notification to external service

        url = "https://miladhaslackcom.slack.com"

        payload = {"message": f"Internal server error occurred: {exc.detail}"}

        headers = {"Content-Type": "application/json"}

        response = requests.post(url, json=payload, headers=headers)

        response.raise_for_status()


# Return the original exception response

    return await handle_http_exception(request, exc)
@app.get("/")
async def root():
    raise HTTPException(status_code=500, detail="something went wrong")
