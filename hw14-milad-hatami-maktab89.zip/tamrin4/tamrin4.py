from fastapi import FastAPI, Request, Form

from fastapi.templating import Jinja2Templates


app = FastAPI()

templates = Jinja2Templates(directory="templates")


items = [

{'name': 'Item 1', 'price': 10.99},

{'name': 'Item 2', 'price': 5.99},

{'name': 'Item 3', 'price': 7.99},

{'name': 'Item 4', 'price': 3.99},

]


@app.get('/index')

def index(request: Request, sort: str = 'asc'):

    if sort == 'asc':

        items.sort(key=lambda x: x['price'])

    elif sort == 'desc':

        items.sort(key=lambda x: x['price'], reverse=True)

    return templates.TemplateResponse('index.html', {'request': request, 'items': items})