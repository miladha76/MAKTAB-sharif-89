from fastapi import FastAPI, Request

from fastapi.responses import HTMLResponse

from fastapi.templating import Jinja2Templates


app = FastAPI()

templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)

async def read_root(request: Request):

    create_account_form = """

        <!DOCTYPE html>

        <html>

            <head>

                <title>Create New User Account</title>

            </head>

            <body>

                <h1>Create New User Account</h1>

                {% if error %}

                    <p style="color:red">{{ error }}</p>

                {% endif %}

                <form method="POST">

                    <label for="username">Username:</label>

                    <input type="text" name="username" id="username" required>

                    <br>

                    <label for="email">Email:</label>

                    <input type="email" name="email" id="email" required>

                    <br>

                    <label for="password">Password:</label>

                    <input type="password" name="password" id="password" required>

                    <br>

                    <label for="confirm_password">Confirm Password:</label>

                    <input type="password" name="confirm_password" id="confirm_password" required>

                    <br>

                    <input type="submit" value="Create Account">

                </form>

                <script>



                    var password = document.getElementById("password");

                    var confirm_password = document.getElementById("confirm_password");


                    function validatePassword() {

                        if (password.value != confirm_password.value) {

                            confirm_password.setCustomValidity("Passwords don't match");

                        }   else {

                            confirm_password.setCustomValidity('');

                        }

                        if (password.value.length < 8 {

                            password.setCustomValidity("Password must be at least 8 characters long");

                        }   else {

                            password.setCustomValidity('');

                        }

                    }


                    password.onchange = validatePassword;

                    confirm_password.onkeyup = validatePassword;

                </script>

            </body>

        </html>

    """

    return HTMLResponse(content=create_account_form, status_code=200)


@app.post("/")

async def create_account(request: Request, username: str, email: str, password: str, confirm_password: str):

    if password != confirm_password:

        return templates.TemplateResponse("create_account.html", {"request": request, "error": "Passwords don't match"})

    if len(password) < 8:

        return templates.TemplateResponse("create_account.html", {"request": request, "error": "Password must be at least 8 characters long"})

# Add code to create the new user account here

    return {"message": "User account created successfully!"}