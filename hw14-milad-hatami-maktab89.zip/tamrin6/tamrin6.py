from fastapi import FastAPI, Request

from fastapi.responses import JSONResponse


app = FastAPI()


@app.post("/calculate_total_price")

async def calculate_total_price(request: Request):

    payload = await request.json()

    items = payload["items"]

    total_price = sum(item["price"] for item in items)

    return JSONResponse(content={"total_price": total_price})

@app.get("/calculate_total_price")
async def calculate_total_price(items: str):

    items_list = eval(items)

    total_price = sum(item["price"] for item in items_list)

    return {"total_price": total_price}