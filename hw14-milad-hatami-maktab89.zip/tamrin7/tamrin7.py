from typing import List

from fastapi import FastAPI, Request

from fastapi.responses import JSONResponse


app = FastAPI()


@app.post("/sum_even_numbers")

async def sum_even_numbers(request: Request):

    payload = await request.json()

    numbers = payload["numbers"]

    even_numbers = [x for x in numbers if x % 2 == 0]

    total_sum = sum(even_numbers)

    return JSONResponse(content={"total_sum": total_sum})